// Fill out your copyright notice in the Description page of Project Settings.

#include "kessler_graphics.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, kessler_graphics, "kessler_graphics" );
